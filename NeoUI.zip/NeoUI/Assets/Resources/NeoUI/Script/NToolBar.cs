using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.Events;
using UnityEngine.UI;
using UnityEngine;
using UnityEditor;


public class NToolBar : Selectable
{
    #region ��������
#if UNITY_EDITOR
    protected override void OnValidate()
    {
        base.OnValidate();
        if (!IsActive())
            return;
        UnityEditor.EditorApplication.delayCall += _OnValidate;
    }
#endif
    #endregion
    public class NToolBarEvent : UnityEvent<GameObject> { };
    private SwipeDetector swipe;
    private static int last_count;
    private GameObject null_item, move_panel, all_item, all_page, null_page;
    [SerializeField]
    private float move_panel_speed;
    [SerializeField]
    private AnimationCurve easing;
    [SerializeField]
    private GameObject content;
    #region ���������
    [Serializable]
    public class OptionData
    {
        #region ����������
        [SerializeField]
        private string m_Text;
        [SerializeField]
        private Sprite m_BackGround;
        [SerializeField]
        private Sprite m_Image;
        [SerializeField]
        private int m_index;
        [SerializeField]
        private GameObject item;
        #endregion
        #region ��������
        public string text { get { return m_Text; } set { m_Text = value; } }
        public Sprite image { get { return m_Image; } set { m_Image = value; } }
        public int Index { get => m_index; set => m_index = value; }
        public Sprite BackGround { get => m_BackGround; set => m_BackGround = value; }
        public GameObject Item
        {
            get => item;
            set
            {
                item = value;
            }
        }
        #endregion
    }
    #endregion
    [SerializeField]
    private List<OptionData> options;
    private IEnumerator Move(Transform target)
    {
        for (float i = 0; i < 1; i += Time.deltaTime / move_panel_speed)
        {
            move_panel.transform.position = Vector3.Lerp(move_panel.transform.position, target.position, easing.Evaluate(i));
            yield return null;
        }
    }
    private IEnumerator MoveTwo(GameObject who, Vector3 target)
    {
        for (float i = 0; i < 1; i += Time.deltaTime / move_panel_speed)
        {
            who.transform.position = Vector3.Lerp(who.transform.position, target, easing.Evaluate(i));
            //last_pos = all_page.transform.position;
            SetActiveAll(true, -1);
            //block_1 = true;
            if (Vector3.Distance(who.transform.position, target) < 0.01f)
            {
                SetActiveAll(false, selected_item_index);
                //block_1 = false;
                yield break;
            }
            yield return null;
        }
    }
    public void OnOn(GameObject who)
    {
        StopAllCoroutines();
        StartCoroutine(Move(who.transform));
        SetPage(who);
    }
    private int selected_item_index;
    private bool left = false, right = false;
    private void OnSwipeEventDown()
    {
    }
    private void OnSwipeEventUp()
    {
        GameObject item;
        NToolBarItem item_;
        if (left)
        {
            try
            {
                item = all_item.transform.GetChild(selected_item_index + 1).gameObject;
                item_ = item.GetComponent<NToolBarItem>();
                item_.OnValueChanged.Invoke(item);
            }
            catch { }
        }
        else if (right)
        {
            try
            {
                item = all_item.transform.GetChild(selected_item_index - 1).gameObject;
                item_ = item.GetComponent<NToolBarItem>();
                item_.OnValueChanged.Invoke(item);
            }
            catch { }
        }
    }
    private void OnSwipeLeft()
    {
        left = true;
        right = false;
    }
    //private void M()
    //{
    //if (!block_1)
    //{
    //    float width = all_page.transform.GetComponent<RectTransform>().rect.width;
    //    if (selected_item_index == 0)
    //    {
    //        all_page.transform.position = new Vector3(Mathf.Clamp((last_pos.x + Input.mousePosition.x - (width + (width / 2))), last_pos.x - Screen.width / 2, last_pos.x), all_page.transform.position.y, 0);
    //    }
    //    else if (selected_item_index == all_page.transform.childCount - 1)
    //    {
    //         all_page.transform.position = new Vector3(Mathf.Clamp((last_pos.x + Input.mousePosition.x - (width / 2)), last_pos.x, last_pos.x + Screen.width / 2), all_page.transform.position.y, 0);
    //    }
    //    else
    //    {
    //        all_page.transform.position = new Vector3(Mathf.Clamp((last_pos.x + Input.mousePosition.x - width), last_pos.x - Screen.width / 2, last_pos.x + Screen.width / 2), all_page.transform.position.y, 0);
    //    }
    //}
    //all_page.transform.position = new Vector3(last_pos.x + Input.mousePosition.x - width, all_page.transform.position.y,0);
    //}
    private void OnSwipeRight()
    {
        right = true;
        left = false;
    }
    private void _OnValidate()
    {
        init();
        if (last_count == options.Count)
        {
        }
        else if (last_count == options.Count - 1)
        {
            AddItem(last_count);
        }
        else if (last_count == options.Count + 1)
        {
            RemoveItem();
        }
        last_count = options.Count;
        RefreshData();
    }
    private void AddItem(int index)
    {
        GameObject item = Instantiate(null_item, Vector3.zero, Quaternion.identity);
        GameObject page = Instantiate(null_page, Vector3.zero, Quaternion.identity);
        item.gameObject.name = "Item: " + index;
        page.gameObject.name = "Page: " + index;
        GameObjectUtility.SetParentAndAlign(item, all_item);
        GameObjectUtility.SetParentAndAlign(page, all_page);
        item.AddComponent<NToolBarItem>();
        item.SetActive(true);
        page.SetActive(true);
        NToolBarItem item_tool = item.GetComponent<NToolBarItem>();
        item_tool.Index = index;
        options[index].Index = index;
        options[index].Item = item;
        page.transform.position = new Vector3(page.transform.position.x + (page.GetComponent<RectTransform>().rect.width * 2 * index), page.transform.position.y, 0);
    }
    private void RemoveItem()
    {
        if (all_item.transform.childCount != options.Count && (options.Count != 0))
        {
            for (int i = 0; i < all_item.transform.childCount; i++)
            {
                try
                {
                    NToolBarItem item = all_item.transform.GetChild(i).GetComponent<NToolBarItem>();
                    if (options[i].Index != item.Index)
                    {
                        try
                        {
                            DestroyImmediate(all_item.transform.GetChild(i).gameObject);
                            DestroyImmediate(all_page.transform.GetChild(i).gameObject);
                        }
                        catch { }

                    }
                }
                catch
                {
                    try
                    {
                        DestroyImmediate(all_item.transform.GetChild(i).gameObject);
                        DestroyImmediate(all_page.transform.GetChild(i).gameObject);
                    }
                    catch { }

                }

            }
        }
        else
        {
            try
            {
                DestroyImmediate(all_item.transform.GetChild(0).gameObject);
                DestroyImmediate(all_page.transform.GetChild(0).gameObject);
            }
            catch { }
        }
    }
    private void init()
    {
        try
        {
            if (gameObject)
            {
                move_panel = content.transform.Find("Move_Panel").gameObject;
                all_item = content.transform.Find("All_Item").gameObject;
                null_item = gameObject.transform.GetChild(0).gameObject;
                null_page = gameObject.transform.GetChild(1).gameObject;
                all_page = gameObject.transform.Find("All_Page").gameObject;
                swipe = all_page.GetComponent<SwipeDetector>();
            }
        }
        catch { }
    }
    private void RefreshData()
    {
        if (all_item.transform.childCount == options.Count)
            for (int i = 0; i < all_item.transform.childCount; i++)
            {
                GameObject item = all_item.transform.GetChild(i).gameObject;
                NToolBarItem tool_item = item.GetComponent<NToolBarItem>();
                tool_item.Button = item.GetComponent<Button>();
                tool_item.Image = item.transform.GetComponentInChildren<Image>();
                tool_item.BackGround = item.transform.GetComponentInChildren<Image>();
                tool_item.Text = item.transform.GetComponentInChildren<Text>();
                tool_item.Text.text = options[i].text;
                tool_item.Image.sprite = options[i].image;
                tool_item.BackGround.sprite = options[i].BackGround;
                tool_item.OnValueChanged.AddListener(OnOn);
            }
    }
    private void SetPage(GameObject item)
    {
        NToolBarItem item_ = item.GetComponent<NToolBarItem>();
        selected_item_index = item_.Index;
        float width = all_page.GetComponent<RectTransform>().rect.width;
        float x = (selected_item_index * (width + width));
        StartCoroutine(MoveTwo(all_page, new Vector3(-(x - width), all_page.transform.position.y, 0)));
    }
    private void SetActiveAll(bool b, int exception)
    {

        for (int i = 0; i < all_page.transform.childCount; i++)
        {
            if (exception != -1)
            {
                if (i != exception)
                {
                    all_page.transform.GetChild(i).gameObject.SetActive(b);
                }
                else
                {
                    all_page.transform.GetChild(i).gameObject.SetActive(!b);
                }
            }
            else if (exception == -1)
                all_page.transform.GetChild(i).gameObject.SetActive(b);
        }
    }
    private void SetMovePanel(GameObject item)
    {
        RectTransform move_rect = move_panel.GetComponent<RectTransform>();
        move_panel.transform.position = item.transform.position;
        UnityEditor.EditorApplication.delayCall += () =>
        {
            RectTransform item_rect = item.GetComponent<RectTransform>();
            move_rect.offsetMin = item_rect.offsetMin;
            move_rect.offsetMax = item_rect.offsetMax;
        };
        SetPage(item);
    }
    protected override void Start()
    {
        try
        {
            init();
            SetMovePanel(all_item.transform.GetChild(0).gameObject);
            RefreshData();
            swipe.m_swipeDown.AddListener(OnSwipeEventDown);
            swipe.m_swipeUp.AddListener(OnSwipeEventUp);
            swipe.m_OnSwipeLeft.AddListener(OnSwipeLeft);
            swipe.m_OnSwipeRight.AddListener(OnSwipeRight);
        }
        catch
        {

        }
    }
}
