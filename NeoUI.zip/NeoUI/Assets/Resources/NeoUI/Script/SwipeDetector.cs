using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using System;

public class SwipeDetector : MonoBehaviour, IPointerUpHandler, IPointerDownHandler
{
    #region Unity Events
    public class SwipeEvent : UnityEvent<float, float> { };
    public class SwipeDown : UnityEvent { };
    public class SwipeUp : UnityEvent { };
    public class OnSwipeUp : UnityEvent { };
    public class OnSwipeDown : UnityEvent { };
    public class OnSwipeRight : UnityEvent { };
    public class OnSwipeLeft : UnityEvent { };

    public SwipeEvent m_SwipeEvent = new SwipeEvent();
    public SwipeDown m_swipeDown = new SwipeDown();
    public SwipeUp m_swipeUp = new SwipeUp();
    public OnSwipeLeft m_OnSwipeLeft = new OnSwipeLeft();
    public OnSwipeRight m_OnSwipeRight = new OnSwipeRight();
    #endregion

    private bool blocker_0 = true;
    private Vector3 press_pos;
    [SerializeField]
    [Range(0f, 1f)]
    private float swipeThreshold = 0.5f;
    public void OnPointerDown(PointerEventData eventData)
    {
        press_pos = Input.mousePosition;
        m_swipeDown.Invoke();
        blocker_0 = false;
    }
    public void OnPointerUp(PointerEventData eventData)
    {
        m_swipeUp.Invoke();
        blocker_0 = true;
    }

    private void Update()
    {
        if (!blocker_0)
        {
            Vector2 pos = (Input.mousePosition - press_pos).normalized;
            m_SwipeEvent.Invoke(pos.x, pos.y);

            if (m_OnSwipeRight != null && pos.x > swipeThreshold)
                m_OnSwipeRight.Invoke();

            if (m_OnSwipeLeft != null && pos.x < -swipeThreshold)
                m_OnSwipeLeft.Invoke();

            //if (OnSwipeUp != null && pos.y > swipeThreshold)
            //    OnSwipeUp.Invoke();

            //if (OnSwipeDown != null && pos.y < -swipeThreshold)
            //    OnSwipeDown.Invoke();
        }
    }
}
