using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine;


public class NToolBarItem : MonoBehaviour, IPointerClickHandler
{
    #region ����������

    [SerializeField]
    private Text m_Text;

    [SerializeField]
    private Image m_BackGround;

    [SerializeField]
    private Image m_Image;

    [SerializeField]
    private RectTransform m_RectTransform;

    [SerializeField]
    private Button m_Button;

    [SerializeField]
    private int m_index;

    [SerializeField]
    private NToolBar.NToolBarEvent m_OnValueChanged = new NToolBar.NToolBarEvent();

    #endregion
    #region ��������
    public Text Text {
        get => m_Text;
        set => m_Text = value;
    }
    public Image Image {
        get => m_Image;
        set => m_Image = value;
    }
    public RectTransform RectTransform {
        get => m_RectTransform;
        set => m_RectTransform = value;
    }

    public int Index {
        get => m_index;
        set => m_index = value;
    }
    public Image BackGround {
        get => m_BackGround;
        set => m_BackGround = value;
    }
    public NToolBar.NToolBarEvent OnValueChanged {
        get => m_OnValueChanged;
        set => m_OnValueChanged = value;
    }
    public Button Button { get => m_Button; set => m_Button = value; }
    #endregion
    void Start()
    {
        Button.onClick.AddListener(delegate {
            OnClick();
        });
    }
    public void OnCancel(BaseEventData eventData)
    {

    }
    public void OnPointerClick(PointerEventData eventData)
    {

    }
    private void OnClick()
    {
        if (gameObject != null)
        {
            OnValueChanged.Invoke(gameObject);
        }
        //EventSystem.current.SetSelectedGameObject(gameObject);
    }
}
