using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;
public static class NeoUI
{
    [MenuItem("GameObject/NeoUI/NToolBar", false, 0)]
    static void G1(MenuCommand menuCommand)
    {
        GameObject go1 = (GameObject)Resources.Load("NeoUI/Prefab/NToolBar");

        GameObject go = GameObject.Instantiate(go1, Vector3.zero, Quaternion.identity);

        if(go.name.Contains("Clone") || go.name.Contains("clone"))
            go.transform.name = go.name.Substring(0, 8);

        GameObjectUtility.SetParentAndAlign(go, menuCommand.context as GameObject);
        
        Undo.RegisterCreatedObjectUndo(go, "Create " + go.name);
        Selection.activeObject = go;
    }

}
